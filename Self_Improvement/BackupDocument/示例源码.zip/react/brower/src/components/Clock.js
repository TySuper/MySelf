(function(global) {
    const { createElement: h, useState, useEffect } = global.React;

    /**
     * 时钟组件
     */
    function Clock() {
        const [time, setTime] = useState(new Date());
        useEffect(() => {

            const interval = setInterval(() => {
                setTime(new Date());
            }, 1 * 1000);

            return () => {
                console.log('清除定时器--->');
                clearInterval(interval);
            }
        }, [])
        return h('div', { style: { color: 'red'} }, [`${time}`]);
    }

    // 导出组件
    window.Clock = window.Clock || Clock;
    
})(window)