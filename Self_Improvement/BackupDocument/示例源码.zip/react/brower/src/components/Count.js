(function(global) {
    const { createElement: h, useState, useEffect } = global.React;

    /**
     * 点击计数
     */
    function Count() {
        const [count, setCount] = useState(0);
        const onClick = () => {
            setCount(count => ++count);
        };
        return h('button', { onClick }, [`${count}`, h('span', {}, ['xxx'])]);
    }

    // 导出组件
    global.Count = global.Count || Count;

})(window)