import React, { useCallback, useRef, useState } from 'react';

/**
 * 利用React.forwardRef转发ref
 */
const LikeInput = React.forwardRef((props, ref) => {
    return <div>Like: <input {...props} ref={ref}></input></div>
})

export default function TestForwardRef(props) {
    const ref = useRef();

    const [text, setText] = useState('');
    const click = useCallback(() => {
        setText(ref.current.value)
    }, [])
    
    return <React.Fragment>
        <LikeInput ref={ref}/>
        <div>{text}</div>
        <br/>
        <button onClick={click}>click</button>
    </React.Fragment>
}