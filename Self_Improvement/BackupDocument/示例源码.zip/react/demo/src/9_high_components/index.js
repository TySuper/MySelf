import React from 'react';

function Button(props) {
    return <button {...props}></button>
}

function Input(props) {
    return <input {...props}/>
}

function withPrefix(Component) {
    // 拓展prefix属性
    return (props) => {
        const { prefix, ...others} = props;
        return <div>{prefix}: <Component {...others}></Component></div>
    }
}

export default function TestHoc() {
    // 带有prefix属性的高阶组件
    const PrefixButton = withPrefix(Button);
    const PrefixInput = withPrefix(Input);

    return <div>
        <PrefixButton prefix="Like">button</PrefixButton>
        <PrefixInput prefix="Test" placeholder="like"/>
    </div>
}