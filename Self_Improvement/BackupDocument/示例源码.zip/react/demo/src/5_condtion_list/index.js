import React from 'react';


/**
 * 条件
 * @param {}} props 
 */
export function TestCondition(props) {
    const { flag } = props;
    return <div>{ flag ? <span>truly</span> : <span>falsly</span> }</div>
}

/**
 * 列表
 */
export function TestList() {
    return (
    <div>
        {
            Array.apply(null, {length: 5}).map((_, index) => <div key={index}>{ index }</div>)
        }
    </div>
    );
}