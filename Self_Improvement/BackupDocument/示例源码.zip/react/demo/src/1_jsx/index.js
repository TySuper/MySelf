import React from 'react';

export default function Test() {
    const msg = 'jsx';
    const divElement =  <div>{ msg }</div>;
    const list = Array.apply(null, { length: 5}).map((_, index) => {
        return <li key={`${index}`}>{ index }</li>
    });
    return (
        <div>
            { divElement }
            <ul>{ list }</ul>
        </div>
    );
}