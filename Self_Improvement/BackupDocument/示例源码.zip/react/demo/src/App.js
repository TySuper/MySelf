import React from 'react';
// import logo from './logo.svg';
import './App.css';
import DisplayItem from './components/DisplayItem/index';
import TestJSX from './1_jsx/index';
import { TestFunc, TestClass } from './2_component/index';
import TestLifeCycle from './3_life_cycle/index';
import TestEvent from './4_event/index';
import { TestCondition, TestList } from './5_condtion_list/index';
import TestForm from './6_form/index';
import TestComunication from './7_comunication/index';
import TestCombination from './8_combination/index';
import TestHoc from './9_high_components/index';
import TestForwardRef from './10_ref_forwardref/index';
import TestPortal from './11_portal/index';
import TestRenderProps from './12_render_props/index';

function App() {
  return (
    <div className="App1">
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      </header> */}
      <DisplayItem title="jsx">
        <TestJSX/>
      </DisplayItem>
      <DisplayItem title="组件">
        <TestFunc name="函数式组件"/>
        <TestClass name="class组件"/>
      </DisplayItem>
      <DisplayItem title="生命周期">
        <TestLifeCycle/>
      </DisplayItem>
      <DisplayItem title="事件处理">
        <TestEvent/>
      </DisplayItem>
      <DisplayItem title="条件及列表渲染">
        <TestCondition flag={ false }/>
        <TestList/>
      </DisplayItem>
      <DisplayItem title="表单处理">
        <TestForm/>
      </DisplayItem>
      <DisplayItem title="组件通信">
        <TestComunication/>
      </DisplayItem>
      <DisplayItem title="组件组合">
         <TestCombination/>
      </DisplayItem>
      <DisplayItem title="高阶组件">
        <TestHoc/>
      </DisplayItem>
      <DisplayItem title="ref转发">
        <TestForwardRef/>
      </DisplayItem>
      <DisplayItem title="portal">
        <TestPortal/>
      </DisplayItem>
      <DisplayItem title="render props">
        <TestRenderProps/>
      </DisplayItem>
    </div>
  );
}

export default App;
