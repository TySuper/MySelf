import React from 'react';

export default class TestEvent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            x: 0,
            y: 0,
        };
        this.onMouseMove = this.onMouseMove.bind(this);
    }

    onMouseMove(event) {
        const { clientX, clientY } = event;
        this.setState({
            x: clientX,
            y: clientY,
        });
    }

    render() {
        const { x, y } = this.state;
        return <div 
            onMouseMove={ this.onMouseMove } 
            style={ { backgroundColor: 'darkcyan', height: '100px'}}
        >
            x:{ x }, y:{ y }
        </div>;
    }
}