import React from 'react';
import { useCallback } from 'react';

function LikeButton(props) {
    const { func } = props;
    
    const click = useCallback(() => {
        func('点击了我');
    }, [func]);

    return <div>自定义button：<button onClick={click}>click</button></div>;
}

export default class TestComunication extends React.Component {

    state = {
        text: '',
    }

    onClick = (val) => {
        this.setState({
            text: val,
        })
    }

    render() {
        return (
            <div>
                { this.state.text }
                <LikeButton func={ this.onClick }/>
            </div>
        );
    }
}