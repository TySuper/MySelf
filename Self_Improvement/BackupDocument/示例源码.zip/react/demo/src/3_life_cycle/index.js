import React from 'react';

export default class TestLifeCycle extends React.Component {
    constructor(props) {
        super(props);
        console.log('TestLifeCycle constructor---->')
        this.state = {
            time: new Date(),
        };
    }

    componentDidMount() {
        console.log('TestLifeCycle componentDidMount---->')
        this.timer = setInterval(() => {
            this.setState({
                time: new Date(),
            });
        }, 1 * 1000);
    }

    componentDidUpdate() {
        console.log('TestLifeCycle componentDidUpdate---->')
    }

    componentWillUnmount() {
        console.log('TestLifeCycle componentWillUnmount---->')
        clearInterval(this.timer);
    }

    render() {
        const { time } = this.state;
        return <div>{ time.toString() }</div>;
    }
}