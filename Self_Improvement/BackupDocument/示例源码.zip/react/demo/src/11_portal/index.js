import React from 'react';
import ReactDOM from 'react-dom';

function Dialog(props) {
    const element = document.createElement('div');
    document.body.appendChild(element);
    
    const { children } = props;
    const content = <div style={{ position: 'absolute', top: 0, right: 0, backgroundColor: 'red'}}>{children}</div>;
    
    return ReactDOM.createPortal(content, element);
}


export default function TestPortal(props) {
    return <Dialog>
        我是弹出框
    </Dialog>
}