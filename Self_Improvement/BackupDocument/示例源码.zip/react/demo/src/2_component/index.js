import React from 'react';

/**
 * 函数式组件(内部没有this)
 * @param {*} props 
 */
export function TestFunc(props) {
    const { name } = props;
    return <div>{ name }</div>;
}


/**
 * class组件，内部可使用props和state
 */
export class TestClass extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            count: 0,
        };
        this.onClick = this.onClick.bind(this);
    }


    onClick() {
        this.setState((state, prop) => {
            let { count } = state;
            return {
                count: ++count,
            }
        });
    }

    render() {
        const { count } = this.state;
        const { name } = this.props;
        return (
            <div>
                <div>{ name }</div>
                <button onClick={ this.onClick }>{ count }</button>
            </div>
        );
    }
}
