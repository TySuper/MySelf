import React from 'react';
import './index.css';

export default function DisplayItem(props) {
    const { title, children } = props;
    return (
        <div className='display-item'>
            <h5 className="title">{title}</h5>
            <div className="body">
                { children }
            </div>
        </div>
    );
}