import React, { useCallback } from 'react';

function Button(props) {
    return <button {...props}></button>
}

/**
 * 组合拓展了Button组件
 * @param {*} props 
 */
function LikeButton(props) {
    return <div>like: <Button {...props}></Button></div>
}

export default function TestCombination() {
    const click = useCallback(() => {
        console.log('clicked like button');
    }, []);
    return <LikeButton onClick={click}>click</LikeButton>;
}