import React from 'react';

function ListItem(props) {
    const { item, children, top } = props;
return <li>{ children ? children(item) : item}{ top(item)}</li>;
}

function List(props) {
    const { data } = props;
    return <ul>
        {
            data.map((item, index) => {
                return (
                <ListItem item={item} key={index} top={(item) => <span>top:{item}</span>}>
                        {
                            (item) => {
                                return <span>haha: {item}</span>
                            }
                        }
                    </ListItem>
                );
            })
        }
    </ul>
}

export default function TestRenderProps(props) {
    return <List data={['item1', 'item2', 'item3']}/>
}