import React from 'react';

export default class TestForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            name: '',
            age: '',
        }
        this.ageInput = React.createRef();
    }

    handleNameChange = (event) => {
        this.setState({
            name: event.target.value,
        });
    }

    handleSubmit = (event) => {
        const { name } = this.state;
        const formData = {
            name,
            age: this.ageInput.current.value,
        }
        console.log(formData);
        event.preventDefault();
    }

    render() {
        const { name } = this.state;
        return (
            <form onSubmit={ this.handleSubmit }>
                {/* 受控技术 */}
                <label>
                    name: <input type="text" name="name" value={name} onChange={this.handleNameChange} />
                </label>
                <br/>
                {/* 非受控技术 */}
                <label>
                    age: <input type="number" name="age" ref={ this.ageInput } />
                </label>
                <br/>
                <input type="submit" value="提交"/>
            </form>
        );
    }

    
}